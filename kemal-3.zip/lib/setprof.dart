import 'package:flutter/material.dart';
import 'a.dart';

void main() {
  runApp(const ProfilePage());
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text(
            "Profile",
            style: TextStyle(fontSize: 16),
          ),
          centerTitle: true,
          backgroundColor: Colors.black,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pop(context);
            },
          ),
        ),
        body: Container(
          color: Colors.black,
          padding: EdgeInsets.all(16),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Image.asset(
                  'images/p1.jpg',
                  fit: BoxFit.cover,
                  height: 200,
                ),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton.icon(
                    onPressed: () {},
                    icon: Icon(Icons.edit),
                    label: Text("Manage Profile"),
                    style: ElevatedButton.styleFrom(
                      primary: Color(0xff959595),
                      onPrimary: Color(0xffffffff),
                      padding:
                          EdgeInsets.symmetric(horizontal: 60, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 24),
                Center(
                  child: Icon(
                    Icons.chat_bubble,
                    size: 24,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  "Tell your friends about Netflix!",
                  style: TextStyle(
                      fontSize: 26,
                      color: Colors.white,
                      fontStyle: FontStyle.italic),
                ),
                SizedBox(height: 8),
                Text(
                  "Share this link so your friends can join the conversation around all your favorite TV shows and movies.",
                  style: TextStyle(
                    fontSize: 16,
                    color: Color(0xffa8a8a8),
                  ),
                ),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      primary: Colors.transparent,
                      onPrimary: Colors.white,
                      padding:
                          EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                      shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white, width: 2),
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.link),
                        SizedBox(width: 8),
                        Text("https://www.netflix.com/"),
                        SizedBox(width: 8),
                        Icon(Icons.copy),
                      ],
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("App Settings"),
                    style: ElevatedButton.styleFrom(primary: Colors.black),
                  ),
                ),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("Account"),
                    style: ElevatedButton.styleFrom(primary: Colors.black),
                  ),
                ),
                SizedBox(height: 16),
                Center(
                  child: ElevatedButton(
                    onPressed: () {},
                    child: Text("help"),
                    style: ElevatedButton.styleFrom(primary: Colors.black),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
