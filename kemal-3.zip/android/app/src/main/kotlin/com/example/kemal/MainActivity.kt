package com.example.kemal

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
